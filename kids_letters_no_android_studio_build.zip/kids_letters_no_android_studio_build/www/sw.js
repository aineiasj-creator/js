const CACHE = 'kids-letter-playground-v2';
const FILES = ['./', './index.html', './manifest.webmanifest', './icons/icon.svg'];
self.addEventListener('install', e => e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES))));
self.addEventListener('fetch', e => e.respondWith(caches.match(e.request).then(r => r || fetch(e.request))));
